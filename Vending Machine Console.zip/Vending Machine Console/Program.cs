﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Vending_Machine_Console
{
    class Program
    {
        public class Product
        {
            public decimal cola = 1.00m;
            public decimal crisps = 0.50m;
            public decimal chocolate = 0.65m;

            public decimal colaStock = 5;
            public decimal crispsStock = 5;
            public decimal chocolateStock = 5;

            public decimal totalPrice = 0;
        }

        public class Coin
        {
            public decimal nickelGrams = 5;
            public decimal dimeGrams = 2.268m;
            public decimal quarterGrams = 5.670m;


            public decimal nickelValue = 0.05m;
            public decimal dimeValue = 0.10m;
            public decimal quarterValue = 0.25m;

            public decimal nickelGramsCount = 0;
            public decimal dimeGramsCount = 0;
            public decimal quarterGramsCount = 0;
        }

        static void introText()
        {
            
            Console.WriteLine("VICTORIAN PLUMBING VENDING MACHINE");

            Console.WriteLine("----------------------------------");
            Console.WriteLine("----------------------------------");

            Console.WriteLine("THIS MACHINE WILL ONLY ACCEPT: Nickel, Dime, Quarter");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("INSTRUCTIONS:");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("1.SELECT PRODUCT(S)");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("2.INSERT COINS");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("3.RECEIVE APPROPRIATE CHANGE");

            Console.WriteLine("----------------------------------");
            Console.WriteLine("----------------------------------");

            Console.WriteLine("PRODUCTS:    COLA(A1)£1.00  -   CRISPS(A2)50P  -   CHOCOLATE(A3)65P");
            Console.WriteLine("----------------------------------");
            Console.WriteLine("ENTER A PRODUCT CODE eg A1, THEN HIT ENTER. ");
            Console.WriteLine("TO PURCHASE MULTIPLE ITEMS ENTER NEXT PRODUCT CODE AFTER HITTING ENTER");
            Console.WriteLine("TO COMPLETE PURCHASE, ENTER 'P'. TO CANCEL, ENTER 'C'");
        }
    




        static void Main(string[] args)
        {

            introText();


        string userInput = Console.ReadLine();

            Product productObj = new Product();
            Coin coinObj = new Coin();

            while (true)
            {
                if (userInput == "A1")
                {

                    productObj.totalPrice = productObj.totalPrice + productObj.cola;
                    userInput = "A1";
                    Console.WriteLine("Total cost: £" + productObj.totalPrice);


                    decimal stockMinus = productObj.colaStock--;
                    Console.WriteLine(stockMinus + " Cola's left");
                    userInput = Console.ReadLine();
                    
                    if (stockMinus <= 1)
                    {

                        //decimal stopCountPrice = productObj.totalPrice - productObj.cola;
                        //productObj.totalPrice = stopCountPrice ;

                        decimal stopCountPrice = productObj.totalPrice - 1.00m;
                        productObj.totalPrice = stopCountPrice;

                        decimal stopStockMinus = productObj.colaStock--;
                        productObj.colaStock = stopStockMinus + stockMinus;

                        Console.WriteLine(" There are no Cola's left");
                        string userInputcoketemp = Console.ReadLine();
                        userInputcoketemp = Console.ReadLine();

                    
                        if (userInputcoketemp == "A2")
                        {
                        userInput = Console.ReadLine();
                        productObj.totalPrice = productObj.totalPrice + 0.50m;

                        }

                        if (userInputcoketemp == "A3")
                        {
                            userInput = Console.ReadLine();
                            productObj.totalPrice = productObj.totalPrice + 0.65m;
                        }
                    }
                    

                }

                else if (userInput == "A2")
                {
                    

                    productObj.totalPrice = productObj.totalPrice + productObj.crisps;
                    userInput = "A2";
                    Console.WriteLine("Total cost: £" + productObj.totalPrice);

                    decimal stockMinus = productObj.crispsStock--;
                    Console.WriteLine(stockMinus + " Crisps's left");
                    userInput = Console.ReadLine();

                    if (stockMinus <= 1)
                    {

                        //decimal stopCountPrice = productObj.totalPrice - productObj.cola;
                        //productObj.totalPrice = stopCountPrice ;

                        decimal stopCountPrice = productObj.totalPrice - 1.00m;
                        productObj.totalPrice = stopCountPrice;

                        decimal stopStockMinus = productObj.crispsStock--;
                        productObj.crispsStock = stopStockMinus + stockMinus;

                        Console.WriteLine(" There are no Crisps left");
                        string userInputcrispstemp = Console.ReadLine();
                        userInputcrispstemp = Console.ReadLine();


                        if (userInputcrispstemp == "A2")
                        {
                            userInput = Console.ReadLine();
                            productObj.totalPrice = productObj.totalPrice + 0.50m;

                        }

                        if (userInputcrispstemp == "A3")
                        {
                            userInput = Console.ReadLine();
                            productObj.totalPrice = productObj.totalPrice + 0.65m;
                        }
                    }

                }

                else if (userInput == "A3")
                {
                    

                    productObj.totalPrice = productObj.totalPrice + productObj.chocolate;
                    userInput = "A3";
                    Console.WriteLine("Total cost: £" + productObj.totalPrice);
                    decimal stockMinus = productObj.colaStock--;
                    Console.WriteLine(stockMinus + " Chocolates left");
                    userInput = Console.ReadLine();

                    if (stockMinus <= 1)
                    {

                        //decimal stopCountPrice = productObj.totalPrice - productObj.cola;
                        //productObj.totalPrice = stopCountPrice ;

                        decimal stopCountPrice = productObj.totalPrice - 1.00m;
                        productObj.totalPrice = stopCountPrice;

                        decimal stopStockMinus = productObj.chocolateStock--;
                        productObj.chocolateStock = stopStockMinus + stockMinus;

                        Console.WriteLine(" There are no Chocolates left");
                        string userInputchoctemp = Console.ReadLine();
                        userInputchoctemp = Console.ReadLine();


                        if (userInputchoctemp == "A2")
                        {
                            userInput = Console.ReadLine();
                            productObj.totalPrice = productObj.totalPrice + 0.50m;

                        }

                        if (userInputchoctemp == "A3")
                        {
                            userInput = Console.ReadLine();
                            productObj.totalPrice = productObj.totalPrice + 0.65m;
                        }
                    }

                }

                else if (userInput == "P")
                {
                    Console.WriteLine("----------------------------------");
                    Console.WriteLine("Total cost: £" + productObj.totalPrice);
                    Console.WriteLine("Please enter coins");
                    Console.WriteLine("Nickel(N)    -   Dime(D) -   Quarter(Q)");
                    string userInputPay = Console.ReadLine();
                    decimal amountPaid = 0;
                  

                    while (true)
                    {
                        if (userInputPay == "N")
                        {
                            decimal nWeightCheck = 5;

                            if (nWeightCheck == coinObj.nickelGrams)

                            {
                                Console.WriteLine("----------------------------------");
                                Console.WriteLine("Nickel inserted.");
                                amountPaid = amountPaid + coinObj.nickelValue;

                                if (amountPaid >= productObj.totalPrice)
                                {
                                    decimal change;
                                    change = amountPaid - productObj.totalPrice;

                                    Console.WriteLine("----------------------------------");
                                    Console.WriteLine("THANK YOU. Please take items & change");
                                    Console.WriteLine("Change given: " + change);
                                    Console.WriteLine("----------------------------------");

                                    introText();
                                    productObj.totalPrice = 0;

                                    userInput = Console.ReadLine();
                                    break;

                                }

                                Console.WriteLine("Total cost: £" + productObj.totalPrice);
                                Console.WriteLine("Amount paid: " + amountPaid);

                                Console.WriteLine("----------------------------------");
                                userInputPay = Console.ReadLine();


                            }
                        }

                        else if (userInputPay == "D")
                        {
                            decimal dWeightCheck = 2.268m;

                            if (dWeightCheck == coinObj.dimeGrams)

                            {
                                {
                                    Console.WriteLine("----------------------------------");
                                    Console.WriteLine("Dime inserted.");
                                    amountPaid = amountPaid + coinObj.dimeValue;

                                    if (amountPaid >= productObj.totalPrice)
                                    {
                                        decimal change;
                                        change = amountPaid - productObj.totalPrice;

                                        Console.WriteLine("----------------------------------");
                                        Console.WriteLine("THANK YOU. Please take items & change");
                                        Console.WriteLine("Change given: " + change);
                                        Console.WriteLine("----------------------------------");

                                        introText();
                                        productObj.totalPrice = 0;

                                        userInput = Console.ReadLine();
                                        break;

                                    }



                                    Console.WriteLine("Total cost: £" + productObj.totalPrice);
                                    Console.WriteLine("Amount paid: " + amountPaid);


                                    Console.WriteLine("----------------------------------");
                                    userInputPay = Console.ReadLine();
                                }

                            }
                        }

                        else if (userInputPay == "Q")
                        {
                            decimal qWeightCheck = 5.670m;

                            if (qWeightCheck == coinObj.quarterGrams)

                            {

                                Console.WriteLine("----------------------------------");
                                Console.WriteLine("Quarter inserted.");
                                amountPaid = amountPaid + coinObj.quarterValue;

                                if (amountPaid >= productObj.totalPrice)
                                {
                                    decimal change;
                                    change = amountPaid - productObj.totalPrice;

                                    Console.WriteLine("----------------------------------");
                                    Console.WriteLine("THANK YOU. Please take items & change");
                                    Console.WriteLine("Change given: " + change);
                                    Console.WriteLine("----------------------------------");

                                    introText();
                                    productObj.totalPrice = 0;

                                    userInput = Console.ReadLine();
                                    break;

                                }

                                Console.WriteLine("Total cost: £" + productObj.totalPrice);
                                Console.WriteLine("Amount paid: " + amountPaid);

                                Console.WriteLine("----------------------------------");
                                userInputPay = Console.ReadLine();
                            }

                        }


                        else if (userInputPay == "C")
                        {
                            productObj.totalPrice = 0;
                            Console.WriteLine("Transaction Cancelled");

                            userInput = Console.ReadLine();
                            break;

                        }

                        else
                        {
                            Console.WriteLine("Coin ejected. Please enter a valid coin ((case sensitive)) ");
                            userInputPay = Console.ReadLine();
                        }

                    }
                }

                else if (userInput == "C")
                {
                    productObj.totalPrice = 0;
                    Console.WriteLine("Transaction Cancelled");
                    userInput = Console.ReadLine();
                    break;
                }

                else
                {
                    Console.WriteLine("Please enter a valid product code ((case sensitive)) ");
                    userInput = Console.ReadLine();
                }


            }


        }
    }
}

